<?php $__env->startSection('content'); ?>
  <div class="panel-body">
    
    <h3>Make an Order</h3><hr>
      <?php echo $__env->make('partials.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col col-md-3">
            <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col col-md-9 menu_action_box">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('create_order')); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('product') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-4 control-label">Select Product</label>

                <div class="col-md-6">
                    <select id="product" class="form-control" name="product" value="<?php echo e(old('product')); ?>" required autofocus>
                        <option></option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('product')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('product')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
                <label for="quantity" class="col-md-4 control-label">Order Quantity</label>

                <div class="col-md-6">
                    <!-- <input id="quantity" name="quantity" type="range" min="1" max="10" value="<?php echo e(old('quantity')); ?>" required autofocus /> -->
                    <select id="quantity" class="form-control" name="quantity" value="<?php echo e(old('quantity')); ?>" required autofocus>
                        <?php for($i = 1; $i<=10; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                
                    <?php if($errors->has('quantity')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('quantity')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        Make Order
                    </button>
                </div>
            </div>
        </form>
    </div>    
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>