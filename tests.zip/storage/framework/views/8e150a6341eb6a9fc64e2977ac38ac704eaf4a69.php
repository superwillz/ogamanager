<?php $__env->startSection('content'); ?>
  <div class="panel-body">
      <?php echo $__env->make('partials.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <h4>View All Users</h4><hr>

    <div class="row">
      <div class="col col-md-3">
          <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
      </div>

      <div class="col col-md-9 menu_action_box">
        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="row">Name</th>
              <th scope="row">Email</th>
              <th scope="row">Type</th>
              <th scope="row">Date Added</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php if($user->type != 'admin'): ?>
                    <a href="/user/<?php echo e($user->id); ?>/delete" onclick="return confirm('Are You Sure You Want to Delete <?php echo e($user->name); ?>\'s Account? This process can\'t be undone')" class="btn btn-xs btn-danger">x</a> 
                  <?php endif; ?>
                  &nbsp; 
                  <a href="/user/<?php echo e($user->id); ?>/edit" title="Click to Edit/Modify"><?php echo e($user->name); ?></a></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                  <?php echo e(ucfirst($user->type)); ?><br>
                  <small>
                    <?php if($user->type == 'staff'): ?>
                      <a href="/user/<?php echo e($user->id); ?>/make/manager">Change to Manager</a>
                    <?php elseif($user->type == 'manager'): ?>
                      <a href="/user/<?php echo e($user->id); ?>/make/staff">Change to Staff</a>
                    <?php endif; ?>  
                  </small>
                </td>
                <td><?php echo e($user->created_at); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </tbody>
        </table>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>