<?php $__env->startSection('content'); ?>
  <div class="panel-body">

  <h3>Viewing All Products in Inventory <small style="font-size:12px;">( 
    <span style="color:red;font-weight:bold;">Out of Stock</span>  -  
    <span style="color:orange;font-weight:bold;"> Going Out of Stock</span> -  
    <span style="color:grey;font-weight:bold;"> Average in Stock</span> -  
    <span style="color:green;font-weight:bold;"> In Stock</span>
  )
  </small></h3>

  <form class="pull-right" action="/product/search" method="POST">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="product_identity" placeholder="Product ID" />  
    <button type="submit" name="search_order" class="btn btn-xs btn-primary">Search</button>  
  </form>

  <hr>

  <div class="row">
      <div class="col col-md-3">
          <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>

      <div class="col col-md-9 menu_action_box">
        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="row">Name</th>
              <th scope="row">Category</th>
              <th scope="row">Description</th>
              <th scope="row">Manufacturer</th>
              <th scope="row">Weight</th>
              <th scope="row">Colour</th>
              <th scope="row">Stock</th>
              <th scope="row">Last Updated By</th>
              <th scope="row">Date</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr style="color:#fff;background:<?php if($product->stock == 0): ?><?php echo e('red'); ?><?php elseif($product->stock <= 5): ?><?php echo e('orange'); ?><?php elseif($product->stock <= 19): ?><?php echo e('grey'); ?><?php else: ?><?php echo e('green'); ?><?php endif; ?>" >
                <td>
                  <?php if((auth()->user()->type == 'admin') || (auth()->user()->type == 'manager')): ?>
                    <a href="/product/<?php echo e($product->id); ?>/delete" style="color:red" onclick='return confirm("Are you sure you want to delete this product?")'  title="Delete Order"><strong>X</strong></a>
                  <?php endif; ?>
                  <?php echo e($product->name); ?>

                </td>
                <td width="80"><?php echo e($product->category->name); ?></td>
                <td width="180"><?php echo e(substr($product->description, 0, 50)); ?>...</td>
                <td><?php echo e($product->manufacturer); ?></td>
                <td><?php echo e($product->weight); ?></td>
                <td><?php echo e($product->colour); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td><?php echo e($product->updated_by->name); ?></td>
                <td><?php echo e($product->updated_at->diffForHumans()); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </tbody>
        </table>
      </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>