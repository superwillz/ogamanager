<?php $__env->startSection('content'); ?>
  <div class="panel-body">
    
    <h3>Add a Product</h3><hr>
      <?php echo $__env->make('partials.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col col-md-3">
            <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col col-md-9 menu_action_box">
                <?php if(count($categories) == 0): ?>
                    <h4 class="alert alert-warning text-center">
                        There are no Product Categories in the Inventory yet. <br>
                        Please <a href="<?php echo e(route('add_category')); ?>">Add a Product Category</a> before you add products.
                    </h4>
                <?php else: ?>
                <form class="form-horizontal" method="POST" action="<?php echo e(route('create_product')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-4 control-label">Product Category</label>

                    <div class="col-md-6">
                        <select id="category" class="form-control" name="category" value="<?php echo e(old('category')); ?>" required autofocus>
                            <option></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('category')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('category')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-4 control-label">Product Name</label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-4 control-label">Product Description</label>

                    <div class="col-md-6">
                        <textarea id="description" type="text" class="form-control" name="description" value="<?php echo e(old('description')); ?>" required autofocus></textarea>

                        <?php if($errors->has('description')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('manufacturer') ? ' has-error' : ''); ?>">
                    <label for="manufacturer" class="col-md-4 control-label">Product Manufacturer</label>

                    <div class="col-md-6">
                        <input id="manufacturer" type="text" class="form-control" name="manufacturer" value="<?php echo e(old('manufacturer')); ?>" required autofocus>

                        <?php if($errors->has('manufacturer')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('manufacturer')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group<?php echo e($errors->has('weight') ? ' has-error' : ''); ?>">
                    <label for="weight" class="col-md-4 control-label">Product Weight</label>

                    <div class="col-md-6">
                        <input id="weight" type="text" class="form-control" name="weight" value="<?php echo e(old('weight')); ?>" required autofocus>

                        <?php if($errors->has('weight')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('weight')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group<?php echo e($errors->has('colour') ? ' has-error' : ''); ?>">
                    <label for="colour" class="col-md-4 control-label">Product Colour</label>

                    <div class="col-md-6">
                        <input id="colour" type="text" class="form-control" name="colour" value="<?php echo e(old('colour')); ?>" required autofocus>

                        <?php if($errors->has('colour')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('colour')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group<?php echo e($errors->has('stock') ? ' has-error' : ''); ?>">
                    <label for="stock" class="col-md-4 control-label">No. of Products to Stock</label>

                    <div class="col-md-6">
                        <input id="stock" type="text" class="form-control" name="stock" value="<?php echo e(old('stock')); ?>" required autofocus>

                        <?php if($errors->has('stock')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('stock')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-primary">
                            Add Product
                        </button>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>