<?php $__env->startSection('content'); ?>
    <div class="panel-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

       <div class="row">
        <div class="col col-md-3">
            <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col col-md-9 menu_action_box text-center">
            <br><br>
            <button class="btn btn-lg btn-danger">
                <strong>13</strong><br><small>Total Orders</small>
            </button>

            <button class="btn btn-lg btn-primary">
                <strong>13</strong><br><small>Total Categories</small>
            </button>

            <button class="btn btn-lg btn-success">
                <strong>13</strong><br><small>Total Products</small>
            </button>

            <button class="btn btn-lg btn-info">
                <strong>13</strong><br><small>Total Users</small>
            </button>

			<!-- div id="peeng-it-api-box"></div> -->
        </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>